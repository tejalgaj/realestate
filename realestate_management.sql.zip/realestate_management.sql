-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2021 at 07:51 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realestate_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_details`
--

CREATE TABLE `contact_us_details` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us_details`
--

INSERT INTO `contact_us_details` (`id`, `name`, `email`, `number`, `message`, `timestamp`) VALUES
(3, 'Patricia L Garrett', 'patricia@gmail.com', '418-670-7258', 'This is test message', '2020-12-18 15:48:38');

-- --------------------------------------------------------

--
-- Table structure for table `property_table`
--

CREATE TABLE `property_table` (
  `property_id` int(11) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `zipcode` varchar(11) NOT NULL,
  `price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_type` varchar(500) NOT NULL,
  `year_built` int(11) NOT NULL,
  `images` text NOT NULL,
  `last_sold` varchar(255) NOT NULL,
  `bathrooms` varchar(1000) NOT NULL,
  `bedrooms` varchar(1000) NOT NULL,
  `kitchen_area` varchar(1000) NOT NULL,
  `dinning_area` varchar(1000) NOT NULL,
  `laundry` varchar(255) NOT NULL,
  `flooring` varchar(500) NOT NULL,
  `amenities` text NOT NULL,
  `total_square_feet` varchar(255) NOT NULL,
  `basement` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property_table`
--

INSERT INTO `property_table` (`property_id`, `street`, `city`, `province`, `zipcode`, `price`, `user_id`, `property_type`, `year_built`, `images`, `last_sold`, `bathrooms`, `bedrooms`, `kitchen_area`, `dinning_area`, `laundry`, `flooring`, `amenities`, `total_square_feet`, `basement`, `created_at`) VALUES
(1, '45,Fairmount Avenue', 'East York', 'ON', 'M4C4X1', 650000, 3, 'condominium', 1990, '', '2003', '2', '3', '850 sq foot', '850 sq foot', 'Brick, Vinyl siding', 'wooden flooring', 'Dryer, Refrigerator, Stove, Water softener, Washer, Hood Fan, Window Coverings, Hot Tub', 'under 1/2 acre', 'unfinish', '2020-12-16 08:02:34'),
(11, '3217  rue Levy', 'Montreal', 'QC', 'H3C 5K4', 65000, 88, 'condominium', 2005, 'https://ap.rdcpix.com/cc49c0acfdfa66ceb5e659fb25b15531l-m657767861od-w1024_h768.jpg,https://ap.rdcpix.com/cc49c0acfdfa66ceb5e659fb25b15531l-m2061447003od-w1024_h768.jpg,https://ap.rdcpix.com/cc49c0acfdfa66ceb5e659fb25b15531l-m3340035117od-w1024_h768.jpg', '2015', '3', '4', '1500sq ft', '800 sq ft', 'not applicable', 'wooden', 'Club Room,Rec Room,Rec Room w/Fireplace,Roof Deck,BBQ Area,Gym', '4,312', 'not_applicable', '2020-12-18 16:37:26'),
(12, '639 WARDEN AVE', 'Toronto', 'ON', 'M1L3Z5', 799999, 3, 'family_home', 1990, 'https://ap.rdcpix.com/5b96b136e49e0560c1f40320b1d1e9c1l-m3573416233od-w1024_h768.jpg,https://ap.rdcpix.com/5b96b136e49e0560c1f40320b1d1e9c1l-m1894205665od-w1024_h768.jpg,https://ap.rdcpix.com/5b96b136e49e0560c1f40320b1d1e9c1l-m4012572971od-w1024_h768.jpg', '1996', '2', '3', '14 ft', '9 ft', 'Brick', 'normal', 'Hospital, Park, Public Transit, Schools', '4,312', 'not_applicable', '2020-12-18 17:22:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_token_auth`
--

CREATE TABLE `tbl_token_auth` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `selector_hash` varchar(255) NOT NULL,
  `is_expired` int(11) NOT NULL DEFAULT 0,
  `expiry_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_token_auth`
--

INSERT INTO `tbl_token_auth` (`id`, `username`, `password_hash`, `selector_hash`, `is_expired`, `expiry_date`) VALUES
(18, 'kevina@gmail.com', '$2y$10$urO49.7taZQySco1EMYX.egL8S0i96d904366B9Blb4fgFkZbxasS', '$2y$10$rhOsBromrJVVMpr3GbTCMu/JXaQiGgQqL3n.aWJPxfBpP0Af260ui', 0, '2021-01-14 11:10:39'),
(19, 'kevin@gmail.com', '$2y$10$RYXR.lFDizZOwP.K9sHO3ukHSV99YRcLL.IZDRm5fgGAxvIFPzwUO', '$2y$10$/E/41NmeP/88fnrzDYg0SuGZP2kpZac3Yz68.ko2am4.iK5vdbXZW', 0, '2021-01-15 09:19:44'),
(20, 'rocky@gmail.com', '$2y$10$9yI3LuDDkpOkEKOhjOROruiJXdsctjTq.oUBvn4w1xRoa0AqZjIPO', '$2y$10$p1mtzKTr682rtaYYeJkvxO3NW3PhE4wOSAvnmOJhws4yLGPUXk7Ym', 0, '2021-01-15 11:47:20'),
(21, 'kelly@gmail.com', '$2y$10$wDQE7PgI2CTeXdhPhYMJ5.hqbQBdp2Nig7GeERpIji/JLGqixVPHm', '$2y$10$673RxYmKSHPkiv/Pr0LL3u2xGmLSHzr9lcLusLAeTGe63QPe/0xKW', 1, '2020-12-17 17:40:30'),
(22, 'kelly@gmail.com', '$2y$10$QKP7FcHm3C.h8Jd7TVkeJedKdOCzf0WXANGNeC75LnXsa.JE9sPHq', '$2y$10$4tepyxhIlDdYMRnOjB0BtOgoRlEjp34TwSmUiHvIKxHCcgyk5EFOu', 0, '2021-01-16 23:40:30');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email_id`, `phone`, `password`, `usertype`, `created_at`) VALUES
(3, 'kelly', 'kelly@gmail.com', '7896541230', '5caa339debd982069ae6b8eeb4156afd', 'admin', '0000-00-00 00:00:00'),
(88, 'Kashish Holms', 'kash@gmail.com', '7896541258', '9b182fe9a724a2b7493b061ea63944a6', 'agent', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us_details`
--
ALTER TABLE `contact_us_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_table`
--
ALTER TABLE `property_table`
  ADD PRIMARY KEY (`property_id`);

--
-- Indexes for table `tbl_token_auth`
--
ALTER TABLE `tbl_token_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us_details`
--
ALTER TABLE `contact_us_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property_table`
--
ALTER TABLE `property_table`
  MODIFY `property_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_token_auth`
--
ALTER TABLE `tbl_token_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
